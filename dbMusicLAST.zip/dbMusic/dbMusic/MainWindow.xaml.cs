﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Console;


namespace dbMusic
{




        public partial class MainWindow : Window
        {

        static MongoClient client = new MongoClient();
        static IMongoDatabase db = client.GetDatabase("local");
        static IMongoCollection<Music> collection = db.GetCollection<Music>("musicColection");


        public void ReadAllDocument()
        {
            List<Music> list = collection.AsQueryable().ToList<Music>();
            dgMusic.ItemsSource = list;
            Music music = (Music)dgMusic.Items.GetItemAt(0);
           // id_tb.Text = music.Id.ToString();
            executor_tb.Text = music.Executor;
            album_tb.Text = music.Album;
            song_tb.Text = music.Song;
            lenght_tb.Text = music.Lenght;
            date_tb.Text = music.Date;
            style_tb.Text = music.Style;
            country_tb.Text = music.Country;


        }

            public MainWindow()
            {
                InitializeComponent();
                ReadAllDocument();
            }

        private void dgMusic_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Music music = (Music)dgMusic.SelectedItem;
           // id_tb.Text = music.Id.ToString();
            executor_tb.Text = music.Executor;
            album_tb.Text = music.Album;
            song_tb.Text = music.Song;
            lenght_tb.Text = music.Lenght;
            date_tb.Text = music.Date;
            style_tb.Text = music.Style;
            country_tb.Text = music.Country;


            
        }



        private void add_Click(object sender, RoutedEventArgs e)
        {                           
            Music music = new Music( executor_tb.Text, album_tb.Text, country_tb.Text, date_tb.Text, lenght_tb.Text, song_tb.Text, style_tb.Text);
            collection.InsertOne(music);
            ReadAllDocument();
        }




        private void update_Click(object sender, RoutedEventArgs e)
        {
            
            /*
            var filter = Builders<Music>.Filter.Eq("_id", id_tb.Text);
            var updateDB = Builders<Music>.Update
                .Set("id", id_tb)
                .Set("executor", executor_tb)
                .Set("album", album_tb)
                .Set("country", country_tb)
                .Set("date", date_tb)
                .Set("lenght", lenght_tb)
                .Set("song", song_tb)
                .Set("style", style_tb);
            collection.UpdateOne(filter, updateDB);

            */
            
            
            var filter = Builders<Music>.Filter.Eq("executor", "3");
            
            var update = Builders<Music>.Update.Set("executor", "4");
            
            
            collection.UpdateOne(filter, update);
            
            ReadAllDocument();
            
        }


        private void delete_Click(object sender, RoutedEventArgs e)
        {
            var filter = Builders<Music>.Filter.Eq("executor", "123");
            collection.DeleteOne(filter);
            ReadAllDocument();
           // collection.DeleteOne(music => music.Id == ObjectId.Parse(id_tb.Text));
           //  ReadAllDocument();
        }


        
        
      

        
        
        
        private void DgMusic_OnCurrentCellChanged(object sender, EventArgs e)
        {
            MessageBox.Show(dgMusic.CurrentCell.Column.DisplayIndex.ToString());
            
           // MessageBox.Show(dgMusic.CurrentCell.Column.GetCellContent());
            
           
           
           
     
        }


        private void DgMusic_OnCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            
            
            
            
            Music music = (Music)dgMusic.SelectedItem;
            // id_tb.Text = music.Id.ToString();
            executor_tb.Text = music.Executor;
            album_tb.Text = music.Album;
            song_tb.Text = music.Song;
            lenght_tb.Text = music.Lenght;
            date_tb.Text = music.Date;
            style_tb.Text = music.Style;
            country_tb.Text = music.Country;

            string temp = music.ToString();
            
            
            
            
            
            
            
           
            //Only handles cases where the cell contains a TextBox
            var editedTextbox = e.EditingElement as TextBox;
            
            
            
            var filter = Builders<Music>.Filter.Eq("executor", "aqw");
          
            
            var update = Builders<Music>.Update.Set("executor", editedTextbox.Text.ToString());
            
            
            collection.UpdateOne(filter, update);
            
            ReadAllDocument();
            
            

        
           
           
           
           
           string str = ((TextBlock) dgMusic.CurrentColumn.GetCellContent(dgMusic.SelectedItem)).Text;

           MessageBox.Show(str);
           
           
           
        }


        
        private void DgMusic_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Get SelectedItems from DataGrid.
            var grid = sender as DataGrid;
           var selected = grid.CurrentCell.Item.ToBsonDocument();
           
          
            MessageBox.Show(selected.ToString());
            
            
        }
        
        
        
        
        }
        
        
        
        
      

        
       
        
        
        
        
   
}
